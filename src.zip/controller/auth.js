const auth = async (req, res) => {
    res.send("Authentication route");
  };
  
export default { auth };
  