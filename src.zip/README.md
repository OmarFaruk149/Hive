This project is created for learning purpose only.
live link is : https://omarfaruk149.github.io/Hive/
