import React from 'react'
import Profile from './Friends/Profile'

export default function Friends() {
  return (
    <div className='bg-gray-700 pt-6'>
      <Profile />
    </div>
  )
}
